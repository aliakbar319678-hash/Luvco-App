import 'package:flutter_riverpod/flutter_riverpod.dart';

enum SplashStatus { idle, loading, done }

final splashProvider = StreamProvider<SplashStatus>((ref) async* {
  yield SplashStatus.loading;
  await Future.delayed(const Duration(milliseconds: 2500));
  yield SplashStatus.done;
});
