import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../core/theme/app_colors.dart';
import '../models/shopping_list_model.dart';

class ShoppingListGridCard extends StatelessWidget {
  final ShoppingListModel list;
  final VoidCallback onMoreTap;

  const ShoppingListGridCard({
    super.key,
    required this.list,
    required this.onMoreTap,
  });

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final scale = size.width / 390;

    return Container(
      decoration: BoxDecoration(
        color: AppColors.pureWhite,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Image + "..." menu row ──
          Stack(
            children: [
              // Image placeholder
              ClipRRect(
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(24),
                ),
                child: Container(
                  width: double.infinity,
                  height: size.width * 0.3,
                  color: Colors.transparent,
                  child: list.imageUrl != null
                      ? (list.imageUrl!.startsWith('http')
                          ? Image.network(list.imageUrl!, fit: BoxFit.contain)
                          : Image.asset(list.imageUrl!, fit: BoxFit.contain))
                      : Center(
                          child: Icon(
                            Icons.image_outlined,
                            color: AppColors.neutralGrey,
                            size: 40 * scale,
                          ),
                        ),
                ),
              ),
              // "..." more button
              Positioned(
                top: 6,
                right: 6,
                child: GestureDetector(
                  onTap: onMoreTap,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    child: Icon(
                      Icons.more_horiz_rounded,
                      color: AppColors.black,
                      size: 24,
                    ),
                  ),
                ),
              ),
            ],
          ),

          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Item count badge ──
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    '${list.itemCount} items',
                    style: GoogleFonts.inter(
                      fontSize: 11 * scale.clamp(0.85, 1.2),
                      color: AppColors.royalPurple,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(height: 4),

                // ── Title ──
                Text(
                  list.title,
                  style: GoogleFonts.inter(
                    fontSize: 15 * scale.clamp(0.85, 1.2),
                    fontWeight: FontWeight.w700,
                    color: AppColors.vibrantPink,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),

                // ── Description ──
                Text(
                  list.description,
                  style: GoogleFonts.inter(
                    fontSize: 12 * scale.clamp(0.85, 1.2),
                    color: AppColors.darkGrey.withValues(alpha: 0.8),
                    fontWeight: FontWeight.w500,
                    height: 1.3,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
